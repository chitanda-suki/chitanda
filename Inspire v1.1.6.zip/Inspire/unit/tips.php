<div id="notification" class="js-msg">
    <div class="title"><span class="icon">&#xe6eb;</span>New Notification</div>
    <div class="info">
        <span class="tips-msg">有朋自远方来，不亦乐乎。</span>
    </div>
</div><!-- #notification #-->