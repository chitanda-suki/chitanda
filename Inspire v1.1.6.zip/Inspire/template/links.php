<?php
/*
	Template Name: 友情链接
*/
get_header(); ?>
	<section class="links-main">
		<div class="items">
			<?php echo links(); ?>
		</div>
	</section>
<?php get_footer(); ?>